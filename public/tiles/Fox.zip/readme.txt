Fox

Idle animation - 17x16 px
Run animation - 19x16 px

License: (Creative Commons Zero, CC0)
http://creativecommons.org/publicdomain/zero/1.0/

Twitter: https://twitter.com/HDSTGames
Patreon: https://www.patreon.com/hdst
Itch: https://hdst.itch.io
OpenGameArt: https://opengameart.org/users/hdst

Support us by crediting HDST or one of the links (this is not mandatory)